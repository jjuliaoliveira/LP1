#include <stdio.h>

float CalculaJovem ()
{
    float Total = 200 + (12*30); //valor base do plano
    return Total;
}

float CalculaAdulto ()
{
    float Total = 300 + (12*60);//valor base do plano
    return Total;
}

int main ()
{
    int Idade;
    int Dependentes;
    float Total;

    printf("Informe a idade: \n");
    scanf ("%i", &Idade);

    printf("Informe numero de dependentes: \n");
    scanf("%i", &Dependentes);

    if (Idade>=16 && Idade<20)
    {
    //chama a funcao calcula jovem
    Total=CalculaJovem();
    //adiciona dependentes
    Total+= Dependentes*10.0;

    printf("Nome do plano: Jovem\n");
    printf("Numero de dependentes:%i\n", Dependentes);
    printf("Valor Anual: %.2f\n", Total); //exibe com duas casas decimais
    }

    else if (Idade >= 20)
    {
    //chama funcao calcula adulto
    Total=CalculaAdulto();
    //desconto dependente
    float Desconto = (60*6)*0.1;
    Total =- Desconto;

    printf("Nome do plano: Adulto\n");
    printf("Numero de dependentes:%i\n", Dependentes);
    printf("Valor Anual: %.2f\n", Total);
    }
    return 0;
}
